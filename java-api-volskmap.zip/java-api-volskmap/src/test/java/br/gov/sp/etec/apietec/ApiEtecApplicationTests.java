package br.gov.sp.etec.apietec;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiEtecApplicationTests {

	@Test
	void contextLoads() {
	}

}
