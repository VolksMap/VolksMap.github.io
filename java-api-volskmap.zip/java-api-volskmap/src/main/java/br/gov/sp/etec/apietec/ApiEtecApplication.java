package br.gov.sp.etec.apietec;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiEtecApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiEtecApplication.class, args);
	}

}
